function p = mTCDF(x, v)
% Description:
%     Return p-values from the t cumulative distribution function.
% Syntax:
%     p = mTCDF(x, v)
   
p = betainc((x + sqrt(x.^2 + v)) ./ (2 * sqrt(x.^2 + v)), v/2, v/2);
p=2*(1-p); % JVS added, so this corresponds to a 2-tailed test.
% e.g. sanity check: p = mTCDF(1.96, 10000) = 0.05
% END OF FILE.
