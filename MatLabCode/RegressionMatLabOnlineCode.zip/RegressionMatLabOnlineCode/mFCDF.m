function p = mFCDF(x, a, b)
% Description:
%     Return p-values from the F cumulative distribution function.
% Syntax:
%     p = mFCDF(x, a, b)    
    p = betainc(a * x ./ (a * x + b), a/2, b/2);
p=1-p; % % JVS added, so this corresponds to a 2-tailed t-test.
% e.g. sanity check: p = mFCDF((1.96)^2, 1,10000) = 0.05
% END OF FILE.